
import React from 'react';
// eslint-disable-next-line import/no-anonymous-default-export
export default props => {
    return (
        <div>
            <h1 className='col text-white  bg-danger mt-5 text-center'>Recode Pro {props.ano}! </h1>
            <br />
            <br />
            <br />
            <h2 className='col text-white  bg-success p-5 text-center'>Muito obrigada</h2>
            <br />
            <br />
            <h3 className='text-dark col bg-warning p-5 text-center'>por tudo!!!</h3>
        </div>
    )
        
}

