import React from 'react';
import Copyright from './Copyright';

function App() {

      return (

            <Copyright ano="2021" />

    );

}

export default App;